import java.util.Scanner;
/**
 * Tic-Tac-Toe: Two-player console, non-graphics
 * @author relkharboutly
 * @date 1/5/2017
 */
public class TTTConsole  {

	public static Scanner in = new Scanner(System.in); // the input Scanner

	public static TicTacToe TTTboard = new TicTacToe();
	/** The entry main method (the program starts here) */
	public static void main(String[] args) {

		int currentState = TicTacToe.PLAYING;
		String userInput;
		int playerSelect = 1;
		int computerPlayer = 2;
		int[] usedMoves = new int[9];
		//game loop
		do {
			TTTboard.printBoard();
			// Print message if game-over
			currentState = TTTboard.checkForWinner();
			/**
			 * get player input here and call setMove(). user should input a number between 0-8
			 */
			Scanner input = new Scanner(System.in);
			
			System.out.println("Enter your move (Enter a position 0 - 8) (Enter 10 to reset board)");
			int playerInput = input.nextInt();
			while (usedMoves[playerInput] == 1){
				System.out.println("Invalid Move, play another move.");
				playerInput = input.nextInt();
			}
			if (playerInput == 10){
				TTTboard.clearBoard();
				System.out.println("Game Reset.");
			}
			// Player Move 
			TTTboard.setMove(playerSelect,playerInput);
			usedMoves[playerInput] = 1;
			TTTboard.printBoard();
			currentState = TTTboard.checkForWinner();
			// Computer Move 
			System.out.println("Computer Move...");
			int computerInput = TTTboard.getComputerMove();
			while (usedMoves[computerInput] == 1){
				computerInput = TTTboard.getComputerMove();
			}
			TTTboard.setMove(computerPlayer, computerInput);
			usedMoves[computerInput] = 1;
			TTTboard.printBoard();
			currentState = TTTboard.checkForWinner();

			if (currentState == ITicTacToe.CROSS_WON) {
				System.out.println("'X' won! Bye!");
			} else if (currentState == ITicTacToe.NOUGHT_WON) {
				System.out.println("'O' won! Bye!");
			} else if (currentState == ITicTacToe.TIE) {
				System.out.println("It's a TIE! Bye!");
			}
			//user can break the loop. remove this line when you finish implementation.



		} while ((currentState == ITicTacToe.PLAYING) ); // repeat if not game-over
	}


}