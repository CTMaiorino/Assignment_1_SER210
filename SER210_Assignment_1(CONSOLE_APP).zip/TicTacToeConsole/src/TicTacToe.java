import java.util.Random;

/**
 * TicTacToe class implements the interface
 * @author relkharboutly
 * @date 1/5/2017
 */
public class TicTacToe implements ITicTacToe {

	// The game board and the game status
	private static final int ROWS = 3, COLS = 3; // number of rows and columns
	private int[][] board = new int[ROWS][COLS]; // game board in 2D array
	private int[] checkBoard = new int[9];
	int currPlayer;

	/**
	 * clear board and set current player   
	 */
	public TicTacToe(){
		//clearBoard();
	}

	@Override
	public void clearBoard() {
		int pos = 0;
		while (pos < 9){
			setMove(0,pos);
			pos++;
		}
	}

	public void setMove(int player, int location) {

		switch (location) {
		case 0:
			board[0][0] = player;
			checkBoard[location] = player;
			break;
		case 1:
			board[0][1] = player;
			checkBoard[location] = player;
			break;
		case 2:
			board[0][2] = player;
			checkBoard[location] = player;
			break;
		case 3:
			board[1][0] = player;
			checkBoard[location] = player;
			break;
		case 4:
			board[1][1] = player;
			checkBoard[location] = player;
			break;
		case 5: 
			board[1][2] = player;
			checkBoard[location] = player;
			break;
		case 6:
			board[2][0] = player;
			checkBoard[location] = player;
			break;
		case 7:
			board[2][1] = player;
			checkBoard[location] = player;
			break;
		case 8:
			board[2][2] = player;
			checkBoard[location] = player;
			break;
		}
	}

	public int getComputerMove() {
		Random rand = new Random();
		int move = rand.nextInt(9);

		//Horizontal Block
		if (checkBoard[0] == 1 && checkBoard[1] == 1 && checkBoard[2] != 2){
			return 2;
		}
		if (checkBoard[3] == 1 && checkBoard[4] == 1 && checkBoard[5] != 2){
			return 5;
		}
		if (checkBoard[6] == 1 && checkBoard[7] == 1 && checkBoard[8] != 2){
			return 8;
		}
		//Vertical Block
		if (checkBoard[0] == 1 && checkBoard[3] == 1 && checkBoard[6] != 2){
			return 6;
		}
		if (checkBoard[1] == 1 && checkBoard[4] == 1 && checkBoard[7] != 2){
			return 7;
		}
		if (checkBoard[2] == 1 && checkBoard[5] == 1 && checkBoard[8] != 2){
			return 8;
		}
		//Diagonal Block
		if (checkBoard[0] == 1 && checkBoard[4] == 1 && checkBoard[8] != 2){
			return 8;
		}
		if (checkBoard[2] == 1 && checkBoard[4] == 1 && checkBoard[6] != 2){
			return 6;
		}

		return move;

	}

	@Override
	public int checkForWinner() {
		// Horizontal Check
		if (checkBoard[0] == 1 && checkBoard[1] == 1 && checkBoard[2] == 1){
			return 2;
		}
		if (checkBoard[3] == 1 && checkBoard[4] == 1 && checkBoard[5] == 1){
			return 2;
		}
		if (checkBoard[6] == 1 && checkBoard[7] == 1 && checkBoard[8] == 1){
			return 2;
		}
		if (checkBoard[0] == 2 && checkBoard[1] == 2 && checkBoard[2] == 2){
			return 3;
		}
		if (checkBoard[3] == 2 && checkBoard[4] == 2 && checkBoard[5] == 2){
			return 3;
		}
		if (checkBoard[6] == 2 && checkBoard[7] == 2 && checkBoard[8] == 2){
			return 3;
		}
		//Vertical Check
		if (checkBoard[0] == 1 && checkBoard[3] == 1 && checkBoard[6] == 1){
			return 2;
		}
		if (checkBoard[1] == 1 && checkBoard[4] == 1 && checkBoard[7] == 1){
			return 2;
		}
		if (checkBoard[2] == 1 && checkBoard[5] == 1 && checkBoard[8] == 1){
			return 2;
		}
		if (checkBoard[0] == 2 && checkBoard[3] == 2 && checkBoard[6] == 2){
			return 3;
		}
		if (checkBoard[1] == 2 && checkBoard[4] == 2 && checkBoard[7] == 2){
			return 3;
		}
		if (checkBoard[2] == 2 && checkBoard[5] == 2 && checkBoard[8] == 2){
			return 3;
		}
		//Diagonal Check
		if (checkBoard[0] == 1 && checkBoard[4] == 1 && checkBoard[8] == 1){
			return 2;
		}
		if (checkBoard[2] == 1 && checkBoard[4] == 1 && checkBoard[6] == 1){
			return 2;
		}
		if (checkBoard[0] == 2 && checkBoard[4] == 2 && checkBoard[8] == 2){
			return 3;
		}
		if (checkBoard[2] == 2 && checkBoard[4] == 2 && checkBoard[6] == 2){
			return 3;
		}
		return 0;
	}
	/**
	 *  Print the game board 
	 */
	public  void printBoard() {
		for (int row = 0; row < ROWS; ++row) {
			for (int col = 0; col < COLS; ++col) {
				printCell(board[row][col]); // print each of the cells
				if (col != COLS - 1) {
					System.out.print("|");   // print vertical partition
				}
			}
			System.out.println();
			if (row != ROWS - 1) {
				System.out.println("-----------"); // print horizontal partition
			}
		}
		System.out.println();
	}

	/**
	 * Print a cell with the specified "content" 
	 * @param content either CROSS, NOUGHT or EMPTY
	 */
	public  void printCell(int content) {
		switch (content) {
		case EMPTY:  System.out.print("   "); break;
		case NOUGHT: System.out.print(" O "); break;
		case CROSS:  System.out.print(" X "); break;
		}
	}

}
